# Oasis POS application package
